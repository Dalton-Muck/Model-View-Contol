package mvc22F;

import javax.swing.*;

public final class JTextFieldInt extends JTextField {
    public JTextFieldInt(int columns){
        super(columns);
    }
    public int getInt(){

    String newTFString;
    int newTFInt = 0;
    try {
        newTFString = getText();
        newTFInt = Integer.parseInt(newTFString);
        System.out.println("good new int " + newTFInt);
    }
    catch(NumberFormatException | NullPointerException nfe){
        setText("BAD INPPUT!");
        JOptionPane.showMessageDialog(null,
                "Invalid input. Not a number.",
                "CS 2300 Error Message:",
                JOptionPane.ERROR_MESSAGE);
        System.out.println("bad new int" + newTFInt);
    }catch (Exception ex){
        System.out.println("Bad error. should not occur");
    }
    return newTFInt;
    }
}
