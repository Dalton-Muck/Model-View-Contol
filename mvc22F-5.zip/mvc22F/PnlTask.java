package mvc22F;

import javax.swing.*;

public class PnlTask extends PnlAbsCtrl{
    private final JLabel jlTask = new JLabel("Set Task:");
    private final JLabel jlSpacer = new JLabel("        ");
    private final JComboBox<Task> jcbTask;

    public PnlTask(Model model) {
        super(model);
        jcbTask = new JComboBox<>();
        for (Task task : Task.values()){
            jcbTask.addItem(task);
        }
        jcbTask.addActionListener(ae -> selectTask());
        add(jlTask);
        add(jlSpacer);
        add(jcbTask);
        System.out.println("In PnlTask c-tor");

    }
    private void selectTask(){
        Task task = jcbTask.getItemAt(jcbTask.getSelectedIndex());
        System.out.println("task: " + task);
        model.setTask(task);
        model.getView().repaint();

    }
}
