package mvc22F;

import javax.swing.*;

public class PnlSizeY extends PnlAbsCtrl{
    private final JLabel jlYSize = new JLabel("Y Size:");
    private final JLabel jlSpacer = new JLabel ("     ");
    private final int JTFI_SIZE = 6;
    private final JTextFieldInt jtfiYSize
            = new JTextFieldInt(JTFI_SIZE);

    public PnlSizeY(Model model) {
        super(model);
        jtfiYSize.setText("" + model.getySize());
        jtfiYSize.addActionListener(ae -> update());
        add(jlYSize);
        add(jlSpacer);
        add(jtfiYSize);
    }
    private void update (){
        int newYSize = jtfiYSize.getInt();
        if(newYSize == 0) {
            jtfiYSize.setText("" + model.getySize());
        }else{
            model.setySize(newYSize);
            model.getView().repaint();
        }
    }
}
