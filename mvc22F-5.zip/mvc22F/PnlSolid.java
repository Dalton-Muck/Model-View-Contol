package mvc22F;

import javax.swing.*;
import java.awt.*;

public class PnlSolid extends PnlAbsCtrl{
    private final JLabel jlSolid = new JLabel("Solid:");

    private final JLabel jlSpacer = new JLabel("     ");
    private final JRadioButton jrbYes = new JRadioButton("Yes");
    private final JRadioButton jrbNo = new JRadioButton("No");
    private final ButtonGroup bgSolid = new ButtonGroup();
    private final JPanel jpButtons = new JPanel();

    public PnlSolid(Model model) {
        super(model);

       // JPanel jpButtons = new JPanel();
       // JRadioButton jrbYes = new JRadioButton("Yes");
        //JRadioButton jrbNo = new JRadioButton("No");
       // ButtonGroup bgSolid = new ButtonGroup ();

        if (model.isSolid()) {
            jrbYes.setSelected(true);
        }else{
            jrbNo.setSelected(true);
        }
        jrbYes.addActionListener(ae -> {
            model.setSolid(true);
            model.getView().repaint();
        });

        jrbNo.addActionListener(ae -> {
            model.setSolid(false);
            model.getView().repaint();
        });
        bgSolid.add(jrbYes);
        bgSolid.add(jrbNo);

        jpButtons.add(jrbYes);
        jpButtons.add(jrbNo);
        jpButtons.setBorder(BorderFactory.createLineBorder(Color.CYAN));
        add(jlSolid);
        add(jlSpacer);
        add(jpButtons);
    }





}
