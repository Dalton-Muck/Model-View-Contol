package mvc22F;

public enum Task {



        INFORMATION,
        RECTANGLE,
        ELLIPSE,
        SIERPINSKI_GASKET
    }

