package mvc22F;

import javax.swing.*;

public class PnlSizeX extends PnlAbsCtrl{
    private final JLabel jlXSize = new JLabel("X Size:");
    private final JLabel jlSpacer = new JLabel ("     ");
            private final int JTFI_SIZE = 6;
            private final JTextFieldInt jtfiXSize
            = new JTextFieldInt(JTFI_SIZE);


    public PnlSizeX(Model model) {
        super(model);
        jtfiXSize.setText("" + model.getxSize());
        jtfiXSize.addActionListener(ae -> update());
        add(jlXSize);
        add(jlSpacer);
        add(jtfiXSize);
    }
    private void update (){
        int newXSize = jtfiXSize.getInt();
        if(newXSize == 0) {
            jtfiXSize.setText("" + model.getxSize());
        }else{
            model.setxSize(newXSize);
            model.getView().repaint();
        }
    }
}
